#started 9:30pm 9/18/26
import flet as ft
import yfinance as yf
import datetime as datetime, time
import time as tm
import numpy as np
import pandas as pd
import flet_charts as fch
import json
from pathlib import Path

name = "dad"
TRANSACTIONS_FILE = Path("transactions.json")

def save_transactions(transactions):
    with open(TRANSACTIONS_FILE, "w") as file:
        json.dump(transactions, file, indent=4)

def load_transactions():
    if TRANSACTIONS_FILE.exists():
        with open(TRANSACTIONS_FILE, "r") as file:
            return json.load(file)

    transactions = [
        {
            "date": "2026-05-21",
            "shares": 2,
            "price": 362.19,
        }
    ]

    save_transactions(transactions)

    return transactions


transactions = load_transactions()


def get_portfolio_data(data):
    shares_series = []
    total_series = []

    for current_date in data.index:
        current_date = current_date.tz_convert("America/New_York")

        owned = 0
        invested = 0

        for transaction in transactions:
            transaction_date = pd.Timestamp(
                transaction["date"],
                tz="America/New_York"
            )

            if transaction_date <= current_date:
                owned += transaction["shares"]
                invested += (
                    transaction["shares"]
                    * transaction["price"]
                )

        shares_series.append(owned)
        total_series.append(invested)

    return np.array(shares_series), np.array(total_series)


def app_creator(page: ft.Page):
    page.title = f"{name}'s portfolio"
    page.padding = 1

    def show_home(e=None):
        page.controls.clear()

        page.add(
            ft.Column(
                controls=[
                    ft.Text(
                        "Home",
                        size=30,
                    ),

                    ft.TextButton(
                        "Transaction History",
                        on_click=show_transactions,
                    ),

                    ft.TextButton(
                        "Graph",
                        on_click=show_graph,
                    ),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=26,
            )
        )

        page.update()

    def show_transactions(e=None):
        page.controls.clear()

        date_field = ft.TextField(
            label="Date",
            hint_text="YYYY-MM-DD",
            width=250,
        )

        shares_field = ft.TextField(
            label="Shares",
            hint_text="3.87",
            width=250,
            keyboard_type=ft.KeyboardType.NUMBER,
        )

        price_field = ft.TextField(
            label="Price",
            hint_text="371.91",
            width=250,
            keyboard_type=ft.KeyboardType.NUMBER,
        )

        transaction_list = ft.ListView(
            spacing=10,
            height=300,
        )

        def refresh_transactions():
            transaction_list.controls.clear()

            for i, transaction in enumerate(transactions):
                transaction_text = ft.Text(
                    f"{transaction['date']} | "
                    f"{transaction['shares']} shares @ "
                    f"${transaction['price']:.2f}"
                )

                remove_button = ft.TextButton(
                    "Remove",
                    on_click=lambda e, index=i: remove_transaction(index),
                )

                transaction_list.controls.append(
                    ft.Row(
                        controls=[
                            transaction_text,
                            remove_button,
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    )
                )

            page.update()

        def remove_transaction(index):
            transactions.pop(index)
            save_transactions(transactions)
            refresh_transactions()

        def add_transaction(e):
            transaction = {
                "date": date_field.value,
                "shares": float(shares_field.value),
                "price": float(price_field.value),
            }

            transactions.append(transaction)
            save_transactions(transactions)

            date_field.value = ""
            shares_field.value = ""
            price_field.value = ""

            refresh_transactions()

        page.add(
            ft.Column(
                controls=[
                    ft.Text(
                        "Transaction History",
                        size=30,
                    ),

                    transaction_list,

                    date_field,
                    shares_field,
                    price_field,

                    ft.Button(
                        "Add Transaction",
                        on_click=add_transaction,
                    ),

                    ft.Button(
                        "Remove Transaction",
                        on_click=remove_transaction,
                    ),

                    ft.TextButton(
                        "Go back",
                        on_click=show_home,
                    ),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=15,
            )
        )

        refresh_transactions()

    def show_graph(e=None, view="1d"):
        page.controls.clear()

        main_points, preclose_line_points, preclose, dates = Market_data(view)
        gain, gain_pct = get_gains(view, preclose, main_points)

        page.add(
            ft.Column(
                controls=[
                    ft.Text(
                        "Graph",
                        size=30,
                    ),

                    ft.Row(
                        controls=[
                            ft.Text(
                                f"G/L ${gain:.2f} | {gain_pct:.2f}%",
                                color=(
                                    ft.Colors.GREEN
                                    if gain >= 0
                                    else ft.Colors.RED
                                ),
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.START,
                    ),

                    ft.Text(
                        f"${main_points[-1].y:.2f}"
                    ),

                    Graph_maker(view),

                    ft.TextButton(
                        "All",
                        on_click=lambda e: show_graph(view="all"),
                    ),

                    ft.TextButton(
                        "1 Day",
                        on_click=lambda e: show_graph(view="1d"),
                    ),

                    ft.TextButton(
                        "Go back",
                        on_click=show_home,
                    ),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=26,
            )
        )

        page.update()

    show_home()


def Market_data(view):
    stock = yf.Ticker("VTI")

    # -------------------------
    # GET MARKET DATA
    # -------------------------

    if view == "1d":

        data = stock.history(
            period="1d",
            interval="1m",
            prepost=True,
        )

        preclose = round(
            stock.info["previousClose"],
            2
        )

    elif view == "all":

        start_date = min(
            t["date"]
            for t in transactions
        )

        data = stock.history(
            start=start_date,
            interval="1d",
            prepost=True,
        )

        # We don't use VTI's previous close
        # as the reference for the "all" graph.
        preclose = 0

        # Get the latest intraday price so the
        # last point is current.
        live = stock.history(
            period="1d",
            interval="1m",
            prepost=True,
        )

        if not data.empty and not live.empty:

            live_price = live["Close"].iloc[-1]

            data.iloc[
                -1,
                data.columns.get_loc("Close")
            ] = live_price

    else:

        return [], [], 0, []

    # -------------------------
    # CHECK DATA
    # -------------------------

    if data.empty:
        return [], [], preclose, []

    # -------------------------
    # TRANSACTION MATH
    # -------------------------

    shares_series, total_series = get_portfolio_data(data)

    # -------------------------
    # BUILD CHART POINTS
    # -------------------------

    main_points = []
    preclose_line_points = []

    for i, (index, row) in enumerate(
        data.iterrows()
    ):

        price = round(
            row["Close"],
            2
        )

        shares = shares_series[i]

        # Your actual portfolio value
        portfolio_value = (
            price * shares
        )

        main_points.append(
            fch.LineChartDataPoint(
                i,
                portfolio_value,
            )
        )

        # -------------------------
        # REFERENCE / BLACK LINE
        # -------------------------

        if view == "1d":

            # Normal previous VTI close
            # multiplied by the shares you own.
            reference_value = (
                preclose * shares
            )

        elif view == "all":

            # How much money you had
            # invested at this point.
            reference_value = (
                total_series[i]
            )

        preclose_line_points.append(
            fch.LineChartDataPoint(
                i,
                reference_value,
            )
        )

    return (
        main_points,
        preclose_line_points,
        preclose,
        data.index
    )


def get_gains(view, preclose, main_points):

    if not main_points:
        return 0, 0

    current_value = main_points[-1].y

    if view == "1d":

        # For 1 day, compare today's portfolio value
        # against yesterday's close.
        #
        # We need the number of shares owned to calculate
        # the dollar gain correctly.

        shares_series, total_series = get_portfolio_data(
            yf.Ticker("VTI").history(
                period="1d",
                interval="1m",
                prepost=True,
            )
        )

        reference = preclose * shares_series[-1]

    elif view == "all":

        # For the entire portfolio,
        # compare current value against money invested.
        shares_series, total_series = get_portfolio_data(
            yf.Ticker("VTI").history(
                start=min(t["date"] for t in transactions),
                interval="1d",
                prepost=True,
            )
        )

        reference = total_series[-1]

    else:
        return 0, 0

    gain = current_value - reference

    if reference != 0:
        gain_pct = (gain / reference) * 100
    else:
        gain_pct = 0

    return round(gain, 2), round(gain_pct, 2)


def Graph_maker(view):

    if view == "1d":

        main_points, preclose_line_points, preclose, dates = Market_data(view)

        # =================================================
        # X TICK LABELS
        # =================================================

        labels = []

        # Only show about 8 labels so they don't overlap.
        step = max(
            1,
            len(dates) // 8
        )

        label_indexes = list(
            range(
                0,
                len(dates),
                step
            )
        )

        # Always show the final time.
        if len(dates) > 0:
            if label_indexes[-1] != len(dates) - 1:
                label_indexes.append(
                    len(dates) - 1
                )

        for i in label_indexes:

            date = dates[i]

            label = date.strftime(
                "%I:%M %p"
            ).lstrip("0")

            labels.append(
                fch.ChartAxisLabel(
                    value=i,
                    label=label,
                )
            )

        series = []

        for i in range(len(main_points) - 1):

            y1 = main_points[i].y
            y2 = main_points[i + 1].y

            r1 = preclose_line_points[i].y
            r2 = preclose_line_points[i + 1].y

            if y1 > r1 and y2 > r2:

                series.append(
                    fch.LineChartData(
                        points=[
                            main_points[i],
                            main_points[i + 1],
                        ],
                        color=ft.Colors.GREEN,
                    )
                )

            elif y1 < r1 and y2 < r2:

                series.append(
                    fch.LineChartData(
                        points=[
                            main_points[i],
                            main_points[i + 1],
                        ],
                        color=ft.Colors.RED,
                    )
                )

            else:

                t = (r1 - y1) / (y2 - y1)

                x1 = main_points[i].x
                x2 = main_points[i + 1].x

                xc = x1 + t * (x2 - x1)

                cross = fch.LineChartDataPoint(
                    xc,
                    r1,
                    show_tooltip=False,
                )

                if y1 > r1:

                    series.append(
                        fch.LineChartData(
                            points=[
                                main_points[i],
                                cross,
                            ],
                            color=ft.Colors.GREEN,
                        )
                    )

                    series.append(
                        fch.LineChartData(
                            points=[
                                cross,
                                main_points[i + 1],
                            ],
                            color=ft.Colors.RED,
                        )
                    )

                else:

                    series.append(
                        fch.LineChartData(
                            points=[
                                main_points[i],
                                cross,
                            ],
                            color=ft.Colors.RED,
                        )
                    )

                    series.append(
                        fch.LineChartData(
                            points=[
                                cross,
                                main_points[i + 1],
                            ],
                            color=ft.Colors.GREEN,
                        )
                    )

        series.append(
            fch.LineChartData(
                points=preclose_line_points,
                color=ft.Colors.BLACK,
            )
        )

        # =================================================
        # CHART
        # =================================================

        chart = fch.LineChart(
            data_series=series,

            left_axis=fch.ChartAxis(
                label_size=70,
                show_labels=True,

                labels=[
                    fch.ChartAxisLabel(
                        value=0,
                        label="$0",
                    ),
                ],
            ),

            bottom_axis=fch.ChartAxis(
                label_size=70,
                show_labels=True,
                labels=labels,
            ),
        )

    elif view == "all":

        main_points, preclose_line_points, preclose, dates = Market_data(view)

        # =================================================
        # X TICK LABELS
        # =================================================

        labels = []

        # Only show about 8 labels.
        step = max(
            1,
            len(dates) // 8
        )

        label_indexes = list(
            range(
                0,
                len(dates),
                step
            )
        )

        # Always show the final date.
        if len(dates) > 0:
            if label_indexes[-1] != len(dates) - 1:
                label_indexes.append(
                    len(dates) - 1
                )

        for i in label_indexes:

            date = dates[i]

            label = date.strftime(
                "%a %m/%d/%y"
            )

            labels.append(
                fch.ChartAxisLabel(
                    value=i,
                    label=label,
                )
            )

        series = []

        for i in range(len(main_points) - 1):

            y1 = main_points[i].y
            y2 = main_points[i + 1].y

            r1 = preclose_line_points[i].y
            r2 = preclose_line_points[i + 1].y

            if y1 > r1 and y2 > r2:

                series.append(
                    fch.LineChartData(
                        points=[
                            main_points[i],
                            main_points[i + 1],
                        ],
                        color=ft.Colors.GREEN,
                    )
                )

            elif y1 < r1 and y2 < r2:

                series.append(
                    fch.LineChartData(
                        points=[
                            main_points[i],
                            main_points[i + 1],
                        ],
                        color=ft.Colors.RED,
                    )
                )

            else:

                t = (r1 - y1) / (y2 - y1)

                x1 = main_points[i].x
                x2 = main_points[i + 1].x

                xc = x1 + t * (x2 - x1)

                cross = fch.LineChartDataPoint(
                    xc,
                    r1,
                    show_tooltip=False,
                )

                if y1 > r1:

                    series.append(
                        fch.LineChartData(
                            points=[
                                main_points[i],
                                cross,
                            ],
                            color=ft.Colors.GREEN,
                        )
                    )

                    series.append(
                        fch.LineChartData(
                            points=[
                                cross,
                                main_points[i + 1],
                            ],
                            color=ft.Colors.RED,
                        )
                    )

                else:

                    series.append(
                        fch.LineChartData(
                            points=[
                                main_points[i],
                                cross,
                            ],
                            color=ft.Colors.RED,
                        )
                    )

                    series.append(
                        fch.LineChartData(
                            points=[
                                cross,
                                main_points[i + 1],
                            ],
                            color=ft.Colors.GREEN,
                        )
                    )

        series.append(
            fch.LineChartData(
                points=preclose_line_points,
                color=ft.Colors.BLACK,
            )
        )

        # =================================================
        # CHART
        # =================================================

        chart = fch.LineChart(
            data_series=series,

            left_axis=fch.ChartAxis(
                label_size=70,
                show_labels=True,

                labels=[
                    fch.ChartAxisLabel(
                        value=0,
                        label="$0",
                    ),
                ],
            ),

            bottom_axis=fch.ChartAxis(
                label_size=70,
                show_labels=True,
                labels=labels,
            ),
        )

    return chart



if __name__ == "__main__":
    import os

    ft.run(
        app_creator,
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
    )




